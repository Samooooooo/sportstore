﻿namespace SportsStore.Models
{
  public class Pages
  {
    public const int  PageSize = 4;
    public int TotalPages { get; set; }
    public int CurrentPage { get; set; }
  }
}
